import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddUserDocument.ComponentComponent } from './add-user-document.component.component';

describe('AddUserDocument.ComponentComponent', () => {
  let component: AddUserDocument.ComponentComponent;
  let fixture: ComponentFixture<AddUserDocument.ComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddUserDocument.ComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddUserDocument.ComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
