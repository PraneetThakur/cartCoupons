import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AddUserDocument } from './add-user-document.component/add-user-document.component.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'my-app';
  constructor(
    private dialogModal: MatDialog,

  )
  {
    
  }
  createModal()
  {
    
      let documentModal;
      documentModal = this.dialogModal.open(AddUserDocument, { data: 1,
        height: '400px',
        width: '600px', })
      documentModal.afterClosed().subscribe((result: string) => {
        if (result == 'save')
        {

        }
          // this.getUserDocuments();
      });
    
  }
}
